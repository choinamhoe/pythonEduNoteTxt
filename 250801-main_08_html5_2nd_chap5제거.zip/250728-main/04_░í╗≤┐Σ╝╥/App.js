import React from "react";
import "./App.css";

function App() {
  return (
    <div>
      <section className="my-section">
        <h2>::before, ::after 예제</h2>
        <p className="pseudo-element">
          이 문장은 앞뒤에 가상 요소가 추가됩니다.
        </p>

        <h2>::first-line, ::first-letter 예제</h2>
        <p className="pseudo-text">
          이 문장은 첫 줄과 첫 글자에 각각 다른 스타일이 적용됩니다. 여러 줄로
          길게 작성해보세요.
        </p>
      </section>
    </div>
  );
}

export default App;
