import React from "react";
import "./App.css";

function App() {
  return (
    <div className="container">
      <h2>블록 요소 vs 인라인 요소</h2>

      <div className="block">이건 블록 요소입니다 (div)</div>
      <p className="block">이건 블록 요소입니다 (p)</p>

      <span className="inline">이건 인라인 요소입니다 (span)</span>
      <a className="inline" href="#">
        이건 인라인 요소입니다 (a)
      </a>

      <div className="notice">
        참고: 블록 요소는 줄을 바꾸고 전체 너비를 차지하지만, 인라인 요소는
        줄바꿈 없이 나란히 나옵니다.
      </div>
    </div>
  );
}

export default App;
