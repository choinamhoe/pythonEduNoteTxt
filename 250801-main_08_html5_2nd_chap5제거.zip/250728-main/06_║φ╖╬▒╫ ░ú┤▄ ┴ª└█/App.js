import React, { useRef } from "react";
import "./App.css";

function App() {
  const htmlCode = `
    <!DOCTYPE html>
      <html lang="ko">
        <head>
          <meta charset="UTF-8">
          <title>간단한 HTML 예제</title>
        </head>
        <body>
          <h1>환영합니다!</h1>
        </body>
      </html>
      `;

  const codeRef = useRef(null);

  const copyToClipboard = () => {
    if (!codeRef.current) return;
    const text = codeRef.current.innerText;

    // 클립보드에 텍스트 복사 (비동기 API)
    navigator.clipboard
      .writeText(text)
      .then(() => alert("코드가 복사되었습니다!"))
      .catch(() => alert("복사에 실패했습니다."));
  };
  return (
    <div className="container">
      <header>
        <h1>환영합니다!</h1>
        <p>HTML 예제를 확인해보세요</p>
      </header>
      <main>
        <h2>이것은 본문입니다</h2>
        <p>
          HTML, CSS를 사용하여 스타일을 적요아고 있습니다. 버튼을 클릭하여
          페이지가 어떻게 반응하는지 확인해보세요
        </p>
        {/* href # 으로 주면 맨위로 이동 */}
        <a href="#">버튼</a>
        <h3>코드 예제</h3>
        <p>아래는 HTML 코드의 예제입니다</p>
        {/* pre 가 있어야 줄바꿈이 코드부분 적용됨*/}
        <pre>
          <code ref={codeRef}>{htmlCode} </code>
          <button onClick={copyToClipboard}>코드복사</button>
        </pre>
      </main>
      <footer>
        <p className="copyright">2025 모든 권리 보유</p>
      </footer>
    </div>
  );
}

export default App;
