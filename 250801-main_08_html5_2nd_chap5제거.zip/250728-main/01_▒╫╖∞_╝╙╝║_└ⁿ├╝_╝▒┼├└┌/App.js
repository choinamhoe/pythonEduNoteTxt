import "./App.css";

function App() {
  return (
    <div>
      <h1>React CSS 선택자 예제</h1>

      <p>이것은 단락입니다.</p>
      <span>이것은 span입니다.</span>

      <input type="text" placeholder="이름" />
      <input type="password" placeholder="비밀번호" />

      <img src="logo.png" alt="로고" />
      <img src="banner.jpg" alt="배너" />

      <a href="https://google.com">구글</a>
      <a href="http://naver.com">네이버</a>

      <div className="btn-primary">버튼 1</div>
      <div className="btn-secondary">버튼 2</div>
      <div className="card">카드</div>

      <input type="text" placeholder="이름" />
      <input type="password" placeholder="비밀번호" />

      <input type="email" placeholder="이메일" />
    </div>
  );
}

export default App;
