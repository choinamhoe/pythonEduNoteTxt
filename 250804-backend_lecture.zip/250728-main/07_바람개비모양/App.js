import React from "react";
import "./App.css";

function App() {
  return (
    <div className="container">
      {/* 왼쪽 */}
      <div style={{ width: "10%" }}>
        <div
          style={{ height: "90%", width: "100%", backgroundColor: "blue" }}
        ></div>
        <div
          style={{ height: "10%", width: "100%", backgroundColor: "green" }}
        ></div>
      </div>
      {/* 오른쪽 */}
      <div style={{ width: "90%" }}>
        <div
          style={{ height: "10%", width: "100%", backgroundColor: "yellow" }}
        ></div>
        {/* 하단 */}
        <div
          style={{
            height: "90%",
            width: "100%",
            display: "flex",
          }}
        >
          <div
            style={{
              height: "100%",
              width: "90%",
            }}
          >
            <div style={{ height: "100%", width: "100%" }}>
              <div
                style={{
                  height: "80vh",
                  width: "100%",
                  backgroundColor: "white",
                }}
              ></div>
              <div style={{ height: "10vh", backgroundColor: "green" }}></div>
            </div>
          </div>
          <div
            style={{ height: "100%", width: "10%", backgroundColor: "red" }}
          ></div>
        </div>
      </div>
    </div>
  );
}

export default App;
