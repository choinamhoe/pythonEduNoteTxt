import React from "react";
import "./App.css";

function App() {
  return (
    <div className="container">
      <h1>가상 클래스 예제</h1>

      <ul>
        <li>아이템 1</li>
        <li>아이템 2</li>
        <li>아이템 3</li>
        <li>아이템 4</li>
      </ul>

      <button className="my-button">클릭해보세요</button>

      <input className="my-input" type="text" placeholder="포커스 해보세요" />
      <input className="my-input" type="text" disabled value="비활성화됨" />

      <label>
        <input type="checkbox" />
        <span>동의합니다</span>
        <label htmlFor="agree">라벨 텍스트</label>
        <span>동의합니다</span>
        <label htmlFor="agree">라벨 텍스트</label>
      </label>

      <p className="exclude">이건 제외 대상입니다.</p>
      <p>이건 스타일이 적용됩니다.</p>
      <p>이건 스타일이 적용됩니다.</p>
    </div>
  );
}

export default App;
