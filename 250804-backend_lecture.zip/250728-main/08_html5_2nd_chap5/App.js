import React from "react";
import "./App.css";

function App() {
  return (
    <div className="container">
      <header>
        <h1>
          <img
            src="images/shop.png"
            width={50}
            height={50}
            alt="Web Shop Logo"
          />
          <a href="/">Web Shop</a>
        </h1>
      </header>
      <nav>
        <ul>
          <li>
            <a href="/">home</a>
          </li>
          <li>
            <a href="/">about us</a>
          </li>
          <li>
            <a href="/">news</a>
          </li>
          <li>
            <a href="/">my account</a>
          </li>
          <li>
            <a href="/">contacts</a>
          </li>
        </ul>
      </nav>
      <div style={{ display: "flex" }}>
        <aside>
          <h4>카테고리</h4>
          <ul>
            <li>컴퓨터</li>
          </ul>
          <ul>
            <li>의류</li>
          </ul>
          <ul>
            <li>음악</li>
          </ul>
          <ul>
            <li>영화</li>
          </ul>
          <ul>
            <li>스포츠/레저</li>
          </ul>
          <ul>
            <li>가구/인테리어</li>
          </ul>
          <ul>
            <li>식품</li>
          </ul>
        </aside>
        <main>
          <div className="product">
            <div>
              <img
                src="images/computer.png"
                alt="컴퓨터"
                width={100}
                height={100}
              />
              <p>
                심플하고 슬림한 본체에 코어i5 3470과지포스 GT630을 장착 CPU:
                인텔 코어i5 3470 (아이비브릿지 3세대) 사용
                <br />
                가격: 1,200,000원
              </p>
              <input type="button" value="쇼핑카드에 추가하기" />
            </div>
            <div>
              <img
                src="images/notebook.png"
                alt="컴퓨터"
                width={100}
                height={100}
              />
              <p>
                Full-HD로 선명한 화면, ISP패널로 시야각도 좋다! CPU: 인텔 코어i7
                3630 QM, CPU: 인텔 코어i7 3630 QM
                <br />
                가격: 1,200,000원
              </p>
              <input type="button" value="쇼핑카드에 추가하기" />
            </div>
          </div>
        </main>
      </div>
      <footer>Copyright (c) 2023 Web Shop</footer>
    </div>
  );
}

export default App;
