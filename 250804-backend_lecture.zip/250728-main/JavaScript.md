# React 명령어

```bash
npx create-react-app <프로젝트명> # 프로젝트 생성(HTML + CSS + javascript)

cd <프로젝트명> # <프로젝트명> 이름의 경로로 이동
npm run start # 프로젝트 실행

npm install 패키지명 # 특정 패키지 설치
npm install # package.json 파일에 기재된 패키지 목록 설치
```

<details>
<summary>프로젝트 생성이 안될 시</summary>

```bash
npx create-react-app@latest <프로젝트명> # 버전 문제로 발생 시 해결됨
```

</details>

```bash
node <파일.js> # <파일.js> 이름의 javascript 파일 실행
```
