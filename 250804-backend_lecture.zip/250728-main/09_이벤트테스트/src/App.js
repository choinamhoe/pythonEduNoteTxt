import logo from "./logo.svg";
import KeyboardEventsExample from "./components/Keyboard";
import ClickEventsExample from "./components/Mouse";
import "./App.css";
import SimpleForm from "./components/Form";
import EventTest from "./components/Load";
import DragEventTest from "./components/Drag";
import TouchEventTest from "./components/Touch";
import ClipboardSelectTest from "./components/Clipboard";

function App() {
  return (
    <>
      <div
        className="App"
        style={{
          width: "100%",
          padding: "20px",
          boxSizing: "border-box", //width 100%에 맞춰 패딩 포함

          display: "grid",
          gridTemplateColumns: "1fr 1fr 1fr", // 3열
          gridTemplateRows: "auto auto", // 2행
          justifyContent: "center", // 가로 가운데 정렬 (필요시)
          alignItems: "center", // 세로 중앙 정렬
        }}
      >
        <ClickEventsExample />
        <KeyboardEventsExample />
        <SimpleForm />
        <DragEventTest />
        <TouchEventTest />
        <ClipboardSelectTest />
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <EventTest />
      </div>
    </>
  );
}

export default App;
