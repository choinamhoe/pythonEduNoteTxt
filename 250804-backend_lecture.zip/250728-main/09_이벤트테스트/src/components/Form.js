import React, { useState } from "react";
/* 
[Form]
폼 : 사용자로부터 데이터를 입력받기 위한 요소들의 집합
(입력창, 체크박스, 라디오버튼, 제출, 초기화 버튼 등을 포함)

Submit: 폼 데이터를 서버로 전송하거나 처리하는 행위
Reset: 폼 데이터를 초기화하는 행위
Submit Trigger: 폼의 제출을 트리거하는 요소 
    (예: Enter 키, 제출 버튼 클릭 등)
*/
function SimpleForm() {
  const [formData, setFormData] = useState({ name: "", email: "" });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`제출된 데이터:\n이름: ${formData.name}\n이메일: ${formData.email}`);
  };

  const handleReset = () => {
    setFormData({ name: "", email: "" });
  };
  const handleFocus = (e) => {
    const { name } = e.target;
    console.log(`${name} 입력란 포커스 됨`);
  };

  const handleBlur = (e) => {
    const { name } = e.target;
    console.log(`${name} 입력란 포커스 해제됨`);
  };
  return (
    <form
      onSubmit={handleSubmit}
      onReset={handleReset}
      style={{
        width: "350px",
        height: "200px",
        backgroundColor: "#d0e8ff",
        border: "2px solid #3399ff",
        borderRadius: "10px",

        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
      }}
    >
      <div>
        <label>
          <span
            style={{
              display: "inline-block",
              width: 60,
              marginRight: 10,
              textAlign: "right",
            }}
          >
            이름:
          </span>{" "}
          <input
            name="name"
            type="text"
            value={formData.name}
            onChange={handleChange}
            onFocus={handleFocus}
            onBlur={handleBlur}
            placeholder="이름 입력"
            required
          />
        </label>
        <br />
        <label>
          <span
            style={{
              display: "inline-block",
              width: 60,
              marginRight: 10,
              textAlign: "right",
            }}
          >
            이메일:
          </span>{" "}
          <input
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            onFocus={handleFocus}
            onBlur={handleBlur}
            placeholder="이메일 입력"
            required
          />
        </label>
        <br />
        <button type="submit">제출</button>
        <button type="reset">초기화</button>
      </div>
    </form>
  );
}

export default SimpleForm;
