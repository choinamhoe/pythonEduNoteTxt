import React from "react";

function KeyboardEventsExample() {
  const handleKeyDown = (e) => {
    // 키를 누르는 순간 바로 발생(권장)
    console.log(`⬇️ keyDown: '${e.key}' | code: ${e.code}`);
  };

  const handleKeyPress = (e) => {
    // 문자가 입력되는 키에 대해서만 발생(Ctrl, Shift 등은 제외)
    console.log(`🔡 keyPress (deprecated): '${e.key}'`);
  };

  const handleKeyUp = (e) => {
    console.log(`⬆️ keyUp: '${e.key}'`);
  };

  return (
    <input
      onKeyDown={handleKeyDown}
      onKeyPress={handleKeyPress}
      onKeyUp={handleKeyUp}
      style={{
        width: "350px",
        height: "200px",
        backgroundColor: "#fff9db",
        border: "2px solid #ffcc00",
        borderRadius: "10px",

        fontSize: "18px",
      }}
      defaultValue="⌨️ 키보드 이벤트 테스트 박스 (클릭 후 키 입력)"
    ></input>
  );
}

export default KeyboardEventsExample;
