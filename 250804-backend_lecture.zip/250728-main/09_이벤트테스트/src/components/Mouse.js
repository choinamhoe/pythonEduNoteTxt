import React from "react";

function ClickEventsExample() {
  const handleClick = (e) => {
    const buttonMap = {
      0: "🖱️ 좌클릭",
      1: "🔘 휠 클릭",
      2: "🖱️ 우클릭",
    };
    console.log(`✅ 일반 클릭 발생 - ${buttonMap[e.button] ?? "기타 버튼"}`);
  };
  const handleDoubleClick = () => {
    console.log("✅ 더블 클릭 발생");
  };

  const handleMouseDown = () => {
    console.log("🟡 마우스 버튼 누름 (mousedown)");
  };

  const handleMouseUp = () => {
    console.log("🟡 마우스 버튼 뗌 (mouseup)");
  };
  const handleMouseMove = () => {
    console.log("📍 마우스 이동 (mousemove)");
  };

  const handleMouseEnter = () => {
    console.log("🟢 부모 mouseenter (자식 이동 영향 ❌)");
  };

  const handleMouseOver = () => {
    console.log("🔵 부모 mouseover (자식 이동 영향 ✅)");
  };

  const handleMouseLeave = () => {
    console.log("🟢 부모 mouseleave (자식 이동 영향 ❌)");
  };

  const handleMouseOut = () => {
    console.log("🔵 부모 mouseout (자식 이동 영향 ✅)");
  };

  const handleContextMenu = (e) => {
    e.preventDefault();
    console.log("🟥 우클릭 (context menu)");
  };

  const handleChildMouseEnter = () => {
    console.log("➡️ 자식 mouseenter");
  };

  const handleChildMouseLeave = () => {
    console.log("⬅️ 자식 mouseleave");
  };

  return (
    <div
      onClick={handleClick}
      onDoubleClick={handleDoubleClick}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onMouseOver={handleMouseOver}
      onMouseOut={handleMouseOut}
      onContextMenu={handleContextMenu}
      style={{
        width: "350px",
        height: "200px",
        backgroundColor: "#f0f0f0",
        border: "2px solid #ccc",
        borderRadius: "10px",
        textAlign: "center",
        lineHeight: "200px",
        cursor: "pointer",
        userSelect: "none",
        position: "relative",
      }}
    >
      클릭 이벤트 테스트 박스
      <div
        onMouseEnter={handleChildMouseEnter}
        onMouseLeave={handleChildMouseLeave}
        style={{
          position: "absolute",
          bottom: "10px",
          left: "50%",
          transform: "translateX(-50%)",
          width: "200px",
          height: "60px",
          backgroundColor: "#cce5ff",
          border: "1px solid #007bff",
          lineHeight: "60px",
          fontSize: "14px",
        }}
      >
        🔷 자식 요소 영역
      </div>
    </div>
  );
}

export default ClickEventsExample;
