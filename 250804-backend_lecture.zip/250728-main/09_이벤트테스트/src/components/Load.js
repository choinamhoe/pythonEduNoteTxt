import React, { useEffect, useState } from "react";

function EventTest() {
  const [resizeCount, setResizeCount] = useState(0);
  const [scrollCount, setScrollCount] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const [unloaded, setUnloaded] = useState(false);
  const [beforeUnloadMessage, setBeforeUnloadMessage] = useState("");

  useEffect(() => {
    // ✅ onload
    alert("✅ [onload] 컴포넌트가 마운트되었습니다.");
    setLoaded(true);

    // ✅ onresize
    const handleResize = () => {
      console.log("window resized");
      setResizeCount((c) => c + 1);
    };
    window.addEventListener("resize", handleResize);

    // ✅ onscroll
    const handleScroll = () => {
      console.log("window scrolled");
      setScrollCount((c) => c + 1);
    };
    window.addEventListener("scroll", handleScroll);

    // ✅ onbeforeunload
    const handleBeforeUnload = (e) => {
      const message = "⚠️ [beforeunload] 페이지를 떠나시겠습니까?";
      alert(message); // Alert 추가
      e.preventDefault();
      e.returnValue = message;
      setBeforeUnloadMessage(message);
      return message;
    };
    window.addEventListener("beforeunload", handleBeforeUnload);

    // ✅ onunload
    return () => {
      alert("❌ [onunload] 컴포넌트가 언마운트됩니다.");
      setUnloaded(true);

      window.removeEventListener("resize", handleResize);
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>React Window Events Test</h2>
      <p>onload (컴포넌트 마운트): {loaded ? "✅" : "❌"}</p>
      <p>onunload (컴포넌트 언마운트): {unloaded ? "✅" : "❌"}</p>
      <p>Window resize 이벤트 발생 횟수: {resizeCount}</p>
      <p>Window scroll 이벤트 발생 횟수: {scrollCount}</p>
      <p>onbeforeunload 메시지: {beforeUnloadMessage || "없음"}</p>
      <p>스크롤 테스트를 위해 페이지가 길게 설정되어 있습니다.</p>
    </div>
  );
}

export default EventTest;
