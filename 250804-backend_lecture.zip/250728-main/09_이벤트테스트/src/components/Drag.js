import React, { useState } from "react";

function DragEventTest() {
  const [log, setLog] = useState([]);
  const [isDragOver, setIsDragOver] = useState(false);

  const addLog = (text) => {
    console.log(text); // 콘솔 로그 출력
    setLog((prev) => [`[${new Date().toLocaleTimeString()}] ${text}`, ...prev]);
  };

  const handleDragStart = (e) => {
    e.dataTransfer.setData("text/plain", "드래그된 아이템");
    addLog("🚀 드래그 시작 (onDragStart)");
  };

  const handleDrag = () => {
    addLog("📦 드래그 중 (onDrag)");
  };

  const handleDragEnd = () => {
    addLog("✅ 드래그 종료 (onDragEnd)");
    setIsDragOver(false);
  };

  const handleDragEnter = () => {
    addLog("🚪 드롭 영역에 진입 (onDragEnter)");
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    addLog("🚶 드롭 영역을 벗어남 (onDragLeave)");
    setIsDragOver(false);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    addLog("🌀 드롭 영역 위에서 드래그 중 (onDragOver)");
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const data = e.dataTransfer.getData("text");
    addLog(`📥 드롭됨! (onDrop) → ${data}`);
    setIsDragOver(false);
  };

  return (
    <div
      style={{
        width: "350px",

        border: "2px solid #888", // 회색 테두리
        borderRadius: "10px", // 둥근 모서리
        boxShadow: "0 4px 8px rgba(0,0,0,0.1)", // 약간의 그림자
        backgroundColor: "#fff", // 흰색 배경

        display: "flex",
        flexDirection: "column",
        alignItems: "center", // 가로 중앙 정렬
      }}
    >
      <div
        draggable
        onDragStart={handleDragStart}
        onDrag={handleDrag}
        onDragEnd={handleDragEnd}
        style={{
          width: "150px",
          height: "100px",
          backgroundColor: "#add8e6",
          textAlign: "center",
          lineHeight: "100px",
          borderRadius: "8px",
          cursor: "grab",
          marginBottom: "20px",
        }}
      >
        🧱 드래그해보세요
      </div>

      <div
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        style={{
          width: "200px",
          height: "150px",
          border: "2px dashed #888",
          borderRadius: "10px",
          textAlign: "center",
          lineHeight: "150px",
          color: "#555",
          backgroundColor: isDragOver ? "#e0ffe0" : "#f9f9f9",
          transition: "background-color 0.2s ease",
        }}
      >
        📩 여기에 드롭하세요
      </div>
    </div>
  );
}

export default DragEventTest;
