import React from "react";

function ClipboardSelectTest() {
  const addLog = (text) => {
    console.log(text);
  };

  const handleCopy = (e) => {
    addLog("📋 복사 이벤트 발생 (onCopy)");
  };

  const handleCut = (e) => {
    addLog("✂️ 잘라내기 이벤트 발생 (onCut)");
  };

  const handlePaste = (e) => {
    let pastedText = "";
    if (e.clipboardData) {
      pastedText = e.clipboardData.getData("text");
    } else if (window.clipboardData) {
      pastedText = window.clipboardData.getData("Text");
    }
    addLog(`📥 붙여넣기 이벤트 발생 (onPaste) - 내용: "${pastedText}"`);
  };

  const handleSelect = (e) => {
    const selection = window.getSelection().toString();
    if (selection.length > 0) {
      addLog(`🔍 텍스트 선택됨 (onSelect) - 선택 내용: "${selection}"`);
    }
  };

  return (
    <div
      style={{
        width: "350px",
        height: "278px",
        border: "2px solid #888",
        borderRadius: "10px",
        backgroundColor: "#f0f8ff",
        fontFamily: "Arial, sans-serif",
        userSelect: "text",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <textarea
        style={{
          width: "80%",
          height: "120px",
          fontSize: "1rem",
          padding: "10px",
          borderRadius: "8px",
          border: "1px solid #ccc",
          resize: "vertical",
          fontFamily: "inherit",
        }}
        placeholder="여기에 텍스트를 입력하고 복사, 잘라내기, 붙여넣기, 선택 해보세요."
        onCopy={handleCopy}
        onCut={handleCut}
        onPaste={handlePaste}
        onSelect={handleSelect}
      />
    </div>
  );
}

export default ClipboardSelectTest;
