import React, { useState } from "react";

function TouchEventTest() {
  const [log, setLog] = useState([]);

  const addLog = (text) => {
    console.log(text);
    setLog((prev) => [`[${new Date().toLocaleTimeString()}] ${text}`, ...prev]);
  };

  const handleTouchStart = (e) => {
    addLog(`👆 Touch Start - 터치 시작 (${e.touches.length}개 손가락)`);
  };

  const handleTouchMove = (e) => {
    addLog(`✋ Touch Move - 터치 이동 (${e.touches.length}개 손가락)`);
  };

  const handleTouchEnd = (e) => {
    addLog(`👋 Touch End - 터치 종료 (${e.changedTouches.length}개 손가락)`);
  };

  const handleTouchCancel = (e) => {
    addLog(`🚫 Touch Cancel - 터치 취소`);
  };

  return (
    <div
      style={{
        width: "350px",
        height: "274px",
        border: "2px solid #888",

        borderRadius: "10px",
        backgroundColor: "#fdf6e3",
        userSelect: "none",
        touchAction: "none",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
      <div
        style={{
          backgroundColor: "#f0e68c",
          borderRadius: "10px",
          width: "80%",
          height: "100px",
          textAlign: "center",
          lineHeight: "100px",
          color: "#333",
          userSelect: "none",
          touchAction: "none",
        }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onTouchCancel={handleTouchCancel}
      >
        여기 터치해보세요
      </div>
    </div>
  );
}

export default TouchEventTest;
