import React from "react";
import "./App.css";

function App() {
  return (
    <div className="parent">
      <p> 자식</p>

      <div className="inner">
        <p> 손자 (후손)</p>
      </div>
    </div>
  );
}

export default App;
