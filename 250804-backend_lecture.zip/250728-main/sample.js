let people = [
  { name: "철수", age: 25 },
  { name: "영희", age: 28 },
  { name: "민수", age: 22 },
];

// 사용 예
people.forEach((person) => {
  console.log(`${person.name}은(는) ${person.age}살입니다.`);
});
