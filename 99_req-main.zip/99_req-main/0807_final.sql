CREATE DATABASE univDB;

create table 학생( 
	학번 CHAR(4) NOT NULL, 
	이름 VARCHAR(20) NOT NULL, 
	주소 VARCHAR(50) NULL DEFAULT "미정",
	학년 INT NOT NULL,
	나이 INT NULL,
	성별 CHAR(1) NOT NULL,
	휴대폰번호 CHAR(14) NULL,
	소속학과 VARCHAR(20) NULL,
	PRIMARY KEY(학번));

create table 과목(
	과목번호 char(4) NOT NULL PRIMARY KEY,
	이름 VARCHAR(20) NOT NULL,
	강의실 CHAR(3) NOT NULL,
	개설학과 VARCHAR(20) NOT NULL, 
	시수 INT NOT NULL);
)

create table 수강(
	학번 char(4) NOT NULL,
	과목번호 CHAR(4) NOT NULL,
	신청날짜 DATE NOT NULL,
	중간성적 INT NULL DEFAULT 0,
	기말성적 INT NULL DEFAULT 0,
	평가학점 CHAR(1) NULL,
	PRIMARY KEY(학번, 과목번호)
);

insert into 과목 values( "c001", "데이터베이스", "126","컴퓨터", 3);
insert INTO 과목 values( "c002", "정보보호", "137","정보통신", 3);
insert into 과목 values( "c003", "모바일웹", "128","컴퓨터", 3);

update 과목 SET 이름 = "모바일 웹앱" where 과목번호="c003";
delete from 과목 where 과목번호="c001";



-- 주석은 Ctrl + /

select * from 학생;
select 학번, 주소 from 학생;

select 주소 from 학생;
select Distinct 주소 from 학생;

select 학년, 주소 from 학생;
select Distinct 학년, 주소 from 학생;

select * from 학생 where 성별="여";
select * from 학생 where 나이>23;

select 이름, 학년, 소속학과, 휴대폰번호 from 학생
where 학년>=2 and 소속학과="컴퓨터";

select * from 학생;
-- 컴퓨터 학과의 학번
select 학번 from 학생 where 소속학과 = "컴퓨터";

select * from 학생 order by 나이;
select * from 학생 order by 나이 desc;

SELECT * from 수강;
select * from 수강 order by 중간성적 desc limit 3;

SELECT * from 학생;
select count(*) from 학생;
select count(1) from 학생;

-- Null 값은 계산하지 않음
SELECT sum(나이)/7 as `7로 나눔`, sum(나이)/6 as `6으로 나눔`, avg(나이) as 평균 from 학생;
select count(*) as 학생수, count(주소) as 학생수2, count(distinct 주소) as 학생수 from 학생;
select * from 학생;

select 성별, count(*) as 숫자, 
	max(나이) as `최고 나이`, 
	min(나이) as `최저 나이` 
	from 학생 group by 성별;
select * from 학생 ;
select 학년, count(*) `학년별 학생수` from 학생 group by 학년;
select 학년, count(*) `학년별 학생수` from 학생 group by 학년 having count(*)>=2;
-- select 나이 from 성별 평균 나이가 24살 이상인 경우만 출력;

select 성별, avg(나이) from 학생 Group by 성별;
select 성별,count(*) from 학생 Group by 성별 having avg(나이)>=24;


select * from 학생 where 주소 is not null;

select * from 학생 where 학번 in ("s001", "s004")  ;

select * from 학생 where (학번 in ("s001", "s004"))&(나이 is null);
select * from 학생;
select * from 학생 where (나이 is null)|( 휴대폰번호 is null);

select 학번 from 수강 where 과목번호="c002";
select * from 학생 where 학번 in ("s001", "s003","s004");

select * from 학생 where 학번 in (
	select 학번 from 수강 where 과목번호="c002");

select * from 수강;
select 학번, 기말성적 - 중간성적 as 점수차 from 수강;

select * from 학생 ;
select 학번 from 수강 where 평가학점 = "A";
select * from 학생 where 학번 in (
	select 학번 from 수강 where 평가학점 = "A");

select * from 학생;
select 과목번호 from 과목 where 이름="정보보호";
select 학번 from 수강 where 과목번호 in ("c002");
select * from 학생 where 학번 in ("s001","s003","s004");

select * from 학생 where 학번 in (
	select 학번 from 수강 where 과목번호 in (
		select 과목번호 from 과목 where 이름="정보보호"
	)
);


-- 1. 중간성적 보다 기말성적이 오른 사람의 학번
select 학번, 중간성적, 기말성적 from 수강 where 기말성적>중간성적;

-- 2. 중간성적 보다 기말성적이 오른 사람의 학번, 이름, 나이
select distinct 학번 from 수강 where 기말성적>중간성적;
select 학번, 이름, 나이 from 학생 where 학번 in 
	("s001","s002","s003","s004");

select 학번, 이름, 나이 from 학생 where 학번 in 
	(select distinct 학번 from 수강 where 기말성적>중간성적);

-- 3. 소속학과별 평균 나이
select 소속학과, avg(나이) as `평균 나이`
	from 학생 group by 소속학과;

-- 4. 강의실 126을 사용하는 학생들의 목록
select 과목번호 from 과목 where 강의실=126; -- c001
select 학번 from 수강 where 과목번호="c001"; -- s002 s003
select * from 학생 where 학번 in ("s002","s003");

select * from 학생 where 학번 in (
	select 학번 from 수강 where 과목번호=(
		select 과목번호 from 과목 where 강의실=126)
)



-- select * from 학생, 수강;
select * from 학생 cross join 수강; -- 모든 경우의 수
-- A
-- 1 e
-- 2 f
-- 2 g
-- 
-- B
-- 2 A
-- 2 B
-- 2 C
-- 
-- A X B
-- 1 e NULL
-- 2 f A
-- 2 f B
-- 2 f C
-- 2 g A
-- 2 g B
-- 2 g C
-- 

select * from 학생 inner join 수강 on 학생.학번=수강.학번;
select * from 학생 left outer join 수강 on 학생.학번=수강.학번;
select * from 학생 right outer join 수강 on 학생.학번=수강.학번;
select * from 학생 join 수강;


select * from 학생;
select * from 학생 where 나이 is null;
update 학생 set 나이 = 24 where 나이 is null;

update 학생 set 나이 = null where 학번='s004';
select * from 학생;

delete FROM  학생 where 나이 is null;
select * from 학생;

-- 현재 존재하는 유저 목록
select USER, HOST from mysql.user;
create user "dev"@"%" identified by "cjcho1992";
grant SELECT, SHOW VIEW on univDB.* TO "dev"@"%";
FLUSH PRIVILEGES;

select USER, HOST from mysql.user;


create table 학생2 
 ( 학번 char(4) Not NULL,
 이름 varchar(20) Not Null,
 주소 varchar(50) default "미정",
 학생 int Not null, 
 나이 int null,
 성별 char(1) not null,
 휴대폰번호 char(13) null,
 소속학과 varchar(20) null,
 primary key (학번),
 unique (휴대폰번호)
 )
 
insert into 학생2 
 	(학번, 이름, 학생, 성별) 
 	values("h001","조창제",0, "남");

-- 해당 줄은 의도적 오류입니다.
insert into 학생2 
 	(학번, 이름, 학생, 성별) 
 	values("h001","홍길동",1, "남");
-- 
insert into 학생2 
 	(학번, 이름, 학생, 성별) 
 	values(null,"홍길동",1, "남");


insert into 학생2 
 	(학번, 이름, 학생, 성별, 휴대폰번호) 
 	values("h002","홍길동",1, "남","010-0000-0000");
insert into 학생2 
 	(학번, 이름, 학생, 성별, 휴대폰번호) 
 	values("h003","홍길동",1, "남","010-0000-0000");

 CREATE table weather(
 	temp float(5),
 	constraint check_temp CHECK (temp<273)
--  constraint check_temp CHECK (temp between -50 and 50)
 );
 
insert into weather	(temp) values(286);

rename table 학생2 to 학생3;

--  테이블 복제
create table 학생4 as select * from 학생3;
drop table 학생4;

alter table weather drop constraint check_temp;


select * from 학생 inner join 수강 on 학생.학번=수강.학번;
select *from 수강;
create view inner_table as
	select 학생.학번, 학생.이름, 학생.주소,
	 수강.과목번호, 수강.중간성적
	from 학생 
	inner join 수강 on 학생.학번=수강.학번;

select * from inner_table;




select  /*+ JOIN_FIXED_ORDER() */
* from 학생 inner join 수강 on 학생.학번=수강.학번;


