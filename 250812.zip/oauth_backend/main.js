// npm init -y
// npm install express
// nodemon main.js
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const app = express();
app.use(express.json());
app.use(
  cors({
    origin: "http://localhost:3000",
    credentials: true,
  })
);
// post 방식으로 token 이름의 api 만들기
app.post("/token", (req, res) => {
  try {
    console.log(111);
    const { token } = req.body;
    // const  token = req.body.token;
    const my_token = jwt.sign({ token }, "SECRET_KEY", { expiresIn: "1h" });
    res.cookie("my_token", my_token, {
      maxAge: 3600000,
      httpOnly: true,
      secure: false,
      sameSite: "lax",
    });
    res.status(200).json({ message: "요청 성공" });
  } catch (e) {
    res.status(500).json({ message: "요청 실패" });
  }
});
app.listen(8000, () => {
  console.log("backend 시작은 nodemon main.js");
});
