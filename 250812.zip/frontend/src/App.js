import { GoogleLogin, GoogleOAuthProvider } from "@react-oauth/google";
import { jwtDecode } from "jwt-decode";
import axios from "axios";
import logo from "./logo.svg";
import "./App.css";
import { useState } from "react";

function App() {
  const [isLogin, setIsLogin] = useState(false);
  const google_id = process.env.REACT_APP_GOOGLE_ID;
  console.log(process.env.REACT_APP_GOOGLE_ID);
  const handleLoginSuccess = async (res) => {
    if (!res) return;
    const idToken = res.credential;
    console.log("idToken", idToken, typeof idToken);
    console.log("decoded", jwtDecode(idToken));
    setIsLogin(true);

    // API 요청
    try {
      const result = await axios.post(
        "http://localhost:8000/token",
        { token: idToken },
        { withCredentials: true }
      );
      console.log(result.data);
    } catch (e) {
      console.log("api 요청 실패: ", e);
    }

    // token 값을 backend로 요청하기
  };
  console.log("isLogin", isLogin);
  return (
    <div
      className="App"
      style={{ display: isLogin === true ? "none" : "block" }}
    >
      <GoogleOAuthProvider clientId={google_id}>
        <GoogleLogin
          onSuccess={handleLoginSuccess}
          onError={() => alert("로그인 실패")}
        ></GoogleLogin>
      </GoogleOAuthProvider>
    </div>
  );
}

export default App;
