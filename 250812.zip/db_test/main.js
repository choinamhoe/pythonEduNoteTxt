// 작업 창
// npm init -y
// npm install mysql2 bcrypt

const mysql = require("mysql2/promise");
const bcrypt = require("bcrypt");

const rootConfig = {
  host: "localhost",
  port: 3307,
  user: "root",
  password: "test",
  database: "auth", // 선택사항
  multipleStatements: true,
};

const con = mysql.createPool(rootConfig);

// 예시
(async () => {
  let query = "show databases;";
  const result = await con.execute(query);
  console.log(result);

  query = "select * from users;";
  const res = await con.execute(query);
  console.log(res);

  const userid = "cjcho";
  const password = "cjcho1992";
  const hashed = await bcrypt.hash(password, 10);
  const match = await bcrypt.compare(password, hashed);
  console.log(password, hashed, match);
})();
// node main.js
