// npm init -y
// npm install mysql2 bcrypt express

const express = require("express");
const mysql = require("mysql2/promise");
const bcrypt = require("bcrypt");
// const bodyParser = require("body-parser");
const rootConfig = {
  host: "localhost",
  port: 3307,
  user: "root",
  password: "test",
  database: "auth",
  multipleStatements: true,
};
const pool = mysql.createPool(rootConfig);
const app = express();
app.use(express.json());
// app.use(bodyParser.json());

app.get("/", async (req, res) => {
  const query = "show databases;";
  const result = await pool.execute(query);
  console.log(result);
  const data = JSON.stringify(result[0]);
  console.log(JSON.stringify(result[0]));
  res.status(200).json({ message: "요청 성공", data: data });
});

app.post("/users", async (req, res) => {
  try {
    const { userid, username, password } = req.body;
    // console.log(password);
    const hashed_pw = await bcrypt.hash(password, 10);
    console.log(hashed_pw);
    let query = "SELECT * FROM users WHERE userid =? ";
    const rows = await pool.execute(query, [userid]);
    console.log(rows[0]);
    // userid 가 DB에 존재하면 길이가 1이상이므로 True
    if (rows[0].length) {
      return res.status(401).json({ message: "DB에 계정이 존재합니다." });
    } else {
      //   userid가 DB에 존재하지 않으면 길이가 0이므로 False
      query =
        "INSERT INTO users (userid, username, password) VALUES (?, ?, ?);";
      await pool.execute(query, [userid, username, hashed_pw]);
      return res
        .status(201)
        .json({ message: "DB에 계정이 생성되었습니다.", id: userid });
    }
  } catch (e) {
    console.log(e);
    return res.status(404).json({ message: "요청 실패", error: e });
  }
});

app.post("/login", async (req, res) => {
  try {
    const { userid, password } = req.body;
    let query = "SELECT password FROM users WHERE userid =? ";
    const rows = await pool.execute(query, [userid]);
    if (rows[0].length) {
      const hashed_pw = rows[0][0].password;
      console.log(hashed_pw);
      const match = await bcrypt.compare(password, hashed_pw);
      if (match) {
        res.cookie("key", "value", {
          maxAge: 3600000,
          httpOnly: true,
          secure: false,
          sameSite: "lax",
        });
        return res.status(200).json({ message: "로그인에 성공하였습니다" });
      } else {
        return res.status(401).json({ message: "비밀번호가 틀렸습니다." });
      }
    } else {
      return res.status(401).json({ message: "유저가 존재하지 않습니다." });
    }
  } catch (e) {
    return res
      .status(500)
      .json({ message: "로그인에 실패하였습니다", error: e });
  }
});
app.delete("/users/:userid", async (req, res) => {
  try {
    const userid = req.params.userid;
    console.log(userid);
    let query = "SELECT * FROM users WHERE userid = ?";
    const result = await pool.execute(query, [userid]);
    console.log(result);
    console.log("length", result[0].length);
    if (result[0].length) {
      query = "DELETE FROM users WHERE userid = ?";
      const result = await pool.execute(query, [userid]);
      console.log(result);
      return res.status(200).json({ message: "유저 삭제에 성공하셨습니다." });
    } else {
      return res
        .status(401)
        .json({ message: "삭제할 계정이 존재하지 않습니다." });
    }
  } catch (e) {
    return res
      .status(500)
      .json({ message: "유저 삭제에 실패하였습니다.", error: e });
  }
});

app.listen(8000, () => {
  console.log("backend 시작은 nodemon 파일명.js");
});
